package com.example.Student_BlackList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentBlackListApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentBlackListApplication.class, args);
	}

}
