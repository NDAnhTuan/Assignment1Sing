package com.example.Student_BlackList.model;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class BlackList {
    private Integer id;
    private Integer blackId;
    private LocalDateTime createdTime;
    private LocalDateTime revokeTime;
    private String createBy;
    private boolean activated;
}
