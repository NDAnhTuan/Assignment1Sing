package com.example.Student_BlackList.model;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Component
public class User {
    private Integer id;
    private String name;

    public User() {
    }

    public User(String name) {
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void validate()
            throws ValidationException
    {
        validateFieldNotEmpty(name, "User name");
    }
    private void validateFieldNotEmpty(String field, String fieldName) throws ValidationException{
        if(field == null || field.trim().isEmpty()){
            throw new ValidationException(fieldName + " is mandatory");
        }
    }
}