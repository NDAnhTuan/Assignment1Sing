package com.example.Student_BlackList.model;

public class ValidationException extends Exception{
    public ValidationException(String message){
        super(message);
    }
}
