package com.example.Student_BlackList.repository;

import com.example.Student_BlackList.model.User;

public class UserRepository {
}
