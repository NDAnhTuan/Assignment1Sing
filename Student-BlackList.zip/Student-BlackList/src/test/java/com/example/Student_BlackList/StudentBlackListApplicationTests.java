package com.example.Student_BlackList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentBlackListApplicationTests {

	@Test
	void contextLoads() {
	}

}
